﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvPremierLeague = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.lblMatchID = new System.Windows.Forms.Label();
            this.lblTeamHome = new System.Windows.Forms.Label();
            this.lblMatchDate = new System.Windows.Forms.Label();
            this.lblTeamAway = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbxMatchID = new System.Windows.Forms.TextBox();
            this.cbxTeamHome = new System.Windows.Forms.ComboBox();
            this.cbxTeamAway = new System.Windows.Forms.ComboBox();
            this.cbxType = new System.Windows.Forms.ComboBox();
            this.cbxTeam = new System.Windows.Forms.ComboBox();
            this.cbxPlayer = new System.Windows.Forms.ComboBox();
            this.dateTimePickerMatch = new System.Windows.Forms.DateTimePicker();
            this.tbxMinute = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPremierLeague)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvPremierLeague
            // 
            this.dgvPremierLeague.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPremierLeague.Location = new System.Drawing.Point(25, 285);
            this.dgvPremierLeague.Name = "dgvPremierLeague";
            this.dgvPremierLeague.RowHeadersWidth = 82;
            this.dgvPremierLeague.RowTemplate.Height = 33;
            this.dgvPremierLeague.Size = new System.Drawing.Size(860, 448);
            this.dgvPremierLeague.TabIndex = 0;
            this.dgvPremierLeague.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPremierLeague_CellContentClick);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(433, 421);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 82;
            this.dataGridView2.RowTemplate.Height = 33;
            this.dataGridView2.Size = new System.Drawing.Size(8, 8);
            this.dataGridView2.TabIndex = 1;
            // 
            // lblMatchID
            // 
            this.lblMatchID.AutoSize = true;
            this.lblMatchID.Location = new System.Drawing.Point(104, 84);
            this.lblMatchID.Name = "lblMatchID";
            this.lblMatchID.Size = new System.Drawing.Size(97, 25);
            this.lblMatchID.TabIndex = 2;
            this.lblMatchID.Text = "Match ID";
            // 
            // lblTeamHome
            // 
            this.lblTeamHome.AutoSize = true;
            this.lblTeamHome.Location = new System.Drawing.Point(73, 171);
            this.lblTeamHome.Name = "lblTeamHome";
            this.lblTeamHome.Size = new System.Drawing.Size(128, 25);
            this.lblTeamHome.TabIndex = 3;
            this.lblTeamHome.Text = "Team Home";
            // 
            // lblMatchDate
            // 
            this.lblMatchDate.AutoSize = true;
            this.lblMatchDate.Location = new System.Drawing.Point(730, 84);
            this.lblMatchDate.Name = "lblMatchDate";
            this.lblMatchDate.Size = new System.Drawing.Size(122, 25);
            this.lblMatchDate.TabIndex = 4;
            this.lblMatchDate.Text = "Match Date";
            // 
            // lblTeamAway
            // 
            this.lblTeamAway.AutoSize = true;
            this.lblTeamAway.Location = new System.Drawing.Point(813, 202);
            this.lblTeamAway.Name = "lblTeamAway";
            this.lblTeamAway.Size = new System.Drawing.Size(124, 25);
            this.lblTeamAway.TabIndex = 5;
            this.lblTeamAway.Text = "Team Away";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(963, 421);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 25);
            this.label5.TabIndex = 6;
            this.label5.Text = "Minute";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(974, 474);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 25);
            this.label6.TabIndex = 7;
            this.label6.Text = "Team";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(974, 520);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 25);
            this.label7.TabIndex = 8;
            this.label7.Text = "Player";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(974, 573);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 25);
            this.label8.TabIndex = 9;
            this.label8.Text = "Type";
            // 
            // tbxMatchID
            // 
            this.tbxMatchID.Enabled = false;
            this.tbxMatchID.Location = new System.Drawing.Point(234, 78);
            this.tbxMatchID.Name = "tbxMatchID";
            this.tbxMatchID.Size = new System.Drawing.Size(235, 31);
            this.tbxMatchID.TabIndex = 10;
            // 
            // cbxTeamHome
            // 
            this.cbxTeamHome.FormattingEnabled = true;
            this.cbxTeamHome.Location = new System.Drawing.Point(234, 171);
            this.cbxTeamHome.Name = "cbxTeamHome";
            this.cbxTeamHome.Size = new System.Drawing.Size(235, 33);
            this.cbxTeamHome.TabIndex = 12;
            this.cbxTeamHome.SelectedIndexChanged += new System.EventHandler(this.cbxTeamHome_SelectedIndexChanged);
            // 
            // cbxTeamAway
            // 
            this.cbxTeamAway.FormattingEnabled = true;
            this.cbxTeamAway.Location = new System.Drawing.Point(988, 199);
            this.cbxTeamAway.Name = "cbxTeamAway";
            this.cbxTeamAway.Size = new System.Drawing.Size(246, 33);
            this.cbxTeamAway.TabIndex = 13;
            this.cbxTeamAway.SelectedIndexChanged += new System.EventHandler(this.cbxTeamAway_SelectedIndexChanged);
            // 
            // cbxType
            // 
            this.cbxType.FormattingEnabled = true;
            this.cbxType.Location = new System.Drawing.Point(1125, 573);
            this.cbxType.Name = "cbxType";
            this.cbxType.Size = new System.Drawing.Size(235, 33);
            this.cbxType.TabIndex = 14;
            // 
            // cbxTeam
            // 
            this.cbxTeam.FormattingEnabled = true;
            this.cbxTeam.Location = new System.Drawing.Point(1125, 466);
            this.cbxTeam.Name = "cbxTeam";
            this.cbxTeam.Size = new System.Drawing.Size(235, 33);
            this.cbxTeam.TabIndex = 15;
            this.cbxTeam.SelectedIndexChanged += new System.EventHandler(this.cbxTeam_SelectedIndexChanged);
            // 
            // cbxPlayer
            // 
            this.cbxPlayer.FormattingEnabled = true;
            this.cbxPlayer.Location = new System.Drawing.Point(1125, 517);
            this.cbxPlayer.Name = "cbxPlayer";
            this.cbxPlayer.Size = new System.Drawing.Size(235, 33);
            this.cbxPlayer.TabIndex = 16;
            // 
            // dateTimePickerMatch
            // 
            this.dateTimePickerMatch.Location = new System.Drawing.Point(911, 78);
            this.dateTimePickerMatch.Name = "dateTimePickerMatch";
            this.dateTimePickerMatch.Size = new System.Drawing.Size(413, 31);
            this.dateTimePickerMatch.TabIndex = 17;
            this.dateTimePickerMatch.ValueChanged += new System.EventHandler(this.dateTimePickerMatch_ValueChanged);
            // 
            // tbxMinute
            // 
            this.tbxMinute.Location = new System.Drawing.Point(1125, 415);
            this.tbxMinute.Name = "tbxMinute";
            this.tbxMinute.Size = new System.Drawing.Size(235, 31);
            this.tbxMinute.TabIndex = 18;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(939, 649);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(151, 36);
            this.btnAdd.TabIndex = 19;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(1163, 649);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(151, 36);
            this.btnDelete.TabIndex = 20;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(639, 774);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(213, 76);
            this.btnInsert.TabIndex = 21;
            this.btnInsert.Text = "Insert";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1412, 881);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.tbxMinute);
            this.Controls.Add(this.dateTimePickerMatch);
            this.Controls.Add(this.cbxPlayer);
            this.Controls.Add(this.cbxTeam);
            this.Controls.Add(this.cbxType);
            this.Controls.Add(this.cbxTeamAway);
            this.Controls.Add(this.cbxTeamHome);
            this.Controls.Add(this.tbxMatchID);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblTeamAway);
            this.Controls.Add(this.lblMatchDate);
            this.Controls.Add(this.lblTeamHome);
            this.Controls.Add(this.lblMatchID);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dgvPremierLeague);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPremierLeague)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPremierLeague;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label lblMatchID;
        private System.Windows.Forms.Label lblTeamHome;
        private System.Windows.Forms.Label lblMatchDate;
        private System.Windows.Forms.Label lblTeamAway;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbxMatchID;
        private System.Windows.Forms.ComboBox cbxTeamHome;
        private System.Windows.Forms.ComboBox cbxTeamAway;
        private System.Windows.Forms.ComboBox cbxType;
        private System.Windows.Forms.ComboBox cbxTeam;
        private System.Windows.Forms.ComboBox cbxPlayer;
        private System.Windows.Forms.DateTimePicker dateTimePickerMatch;
        private System.Windows.Forms.TextBox tbxMinute;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnInsert;
    }
}

